def read_file_contents(file_path):
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except FileNotFoundError:
        return None

def write_file_contents(file_path, content):
    with open(file_path, 'w') as file:
        file.write(content)

if __name__ == "__main__":
    test_file_path = "test.txt"
    content = "This is a test file."
    write_file_contents(test_file_path, content)
    print(f"Written to {test_file_path}: {read_file_contents(test_file_path)}")