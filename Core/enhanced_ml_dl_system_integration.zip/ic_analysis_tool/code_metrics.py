def count_lines_of_code(code):
    return len(code.split('\n'))

def count_non_empty_lines_of_code(code):
    return len([line for line in code.split('\n') if line.strip() != ''])

def calculate_average_line_length(code):
    lines = code.split('\n')
    total_length = sum(len(line) for line in lines)
    return total_length / len(lines) if lines else 0

if __name__ == "__main__":
    code = '''
def example_function():
    print("Hello, World!")
    print("This is an example of calculating code metrics.")
    
    '''
    print("Total Lines of Code:", count_lines_of_code(code))
    print("Non-Empty Lines of Code:", count_non_empty_lines_of_code(code))
    print("Average Line Length:", calculate_average_line_length(code))