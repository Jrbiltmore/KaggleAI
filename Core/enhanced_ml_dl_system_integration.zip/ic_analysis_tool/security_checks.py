import ast

class SecurityAnalyzer:
    def __init__(self, code):
        self.code = code
        self.tree = ast.parse(code)

    def check_insecure_functions(self):
        insecure_functions = ['eval', 'exec']
        issues = []
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id in insecure_functions:
                    issues.append(f"Use of insecure function: {node.func.id}")
        return issues

    def check_hardcoded_secrets(self):
        patterns = ['password', 'secret', 'token']
        issues = []
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and any(pattern in target.id.lower() for pattern in patterns):
                        issues.append(f"Potential hardcoded secret: {target.id}")
        return issues

def analyze_security(code):
    analyzer = SecurityAnalyzer(code)
    insecure_functions = analyzer.check_insecure_functions()
    hardcoded_secrets = analyzer.check_hardcoded_secrets()
    return {
        "insecure_functions": insecure_functions,
        "hardcoded_secrets": hardcoded_secrets
    }

if __name__ == "__main__":
    code = '''
username = "admin"
password = "secretPassword123"
eval("print('Hello, World!')")
    '''
    results = analyze_security(code)
    print(results)